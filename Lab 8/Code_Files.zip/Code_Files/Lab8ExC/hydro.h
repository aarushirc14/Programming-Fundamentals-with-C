//ENSF 337 Lab 8- Ex.C
//hydro.h
//Creator: Aarushi Roy Choudhury

void displayHeader();
int main();
int readData();
int menu();
void display();
void addData();
void removeData();
double Average();
void  SaveData();
void pressEnter();